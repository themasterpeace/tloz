from django.apps import AppConfig


class ZeldaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'zelda'
